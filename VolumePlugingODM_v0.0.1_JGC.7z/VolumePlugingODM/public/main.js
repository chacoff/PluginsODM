PluginsAPI.Map.willAddControls([
    	'VolumePlugingODM/build/app.js',
    	'VolumePlugingODM/build/app.css'
	], function(args, App){
	new App(args.map);
});
