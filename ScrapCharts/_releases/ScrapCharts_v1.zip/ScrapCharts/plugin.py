from datetime import datetime

from django import forms
from django.contrib.auth.decorators import login_required
from django.db.models import Count
from django.db.models.functions import TruncMonth
from django.shortcuts import render
from django.utils.translation import gettext as _

from app.plugins import PluginBase, Menu, MountPoint


class Plugin(PluginBase):

    def main_menu(self):
        return [Menu("Reports", self.public_url(""), "fa fa-chart-pie fa-fw")]

    def include_js_files(self):
        return ['Chart.min.js']

    def app_mount_points(self):
        @login_required
        def volume_graphs(request):
            x_values = [1, 2, 3, 4, 5, 6, 7]
            y_values = [1, 2, 3, 4, 5, 6, 7]
            label = "Data"

            template_args = {
                'x_values': x_values,
                'y_values': y_values,
                'label': label,
            }

            return render(request, self.template_path("volume_graphs.html"), template_args)

        return [
            MountPoint('$', volume_graphs)
        ]