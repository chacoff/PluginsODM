from datetime import datetime
import pandas as pd
import numpy as np

from django import forms
from django.contrib.auth.decorators import login_required
from django.db.models import Count
from django.db.models.functions import TruncMonth
from django.shortcuts import render
from django.utils.translation import gettext as _
from django.http import JsonResponse

from app.plugins import PluginBase, Menu, MountPoint


class Plugin(PluginBase):

    def main_menu(self):
        return [Menu("Reports", self.public_url(""), "fa fa-chart-line fa-fw")]

    def include_js_files(self):
        return ['Chart.min.js']

    def app_mount_points(self):
        @login_required
        def volume_graphs(request):
            x_values, y_values, flights = get_data_from_db()
            label = "Volume"

            template_args = {
                'x_values': x_values,
                'y_values': y_values,
                'label': label,
                'xy_pairs': list(zip(x_values, y_values)),
                'n_piles': len(x_values),
                'flights': flights
            }

            return render(request, self.template_path("volume_graphs.html"), template_args)

        @login_required
        def get_flight_data(request):
            flight_day = request.GET.get("flightDay", "")
            x_values, y_values, _ = get_data_from_db(flight_day)
            return JsonResponse({"x_values": list(x_values), "y_values": list(y_values)})

        # return [MountPoint('$', volume_graphs)]
        return [
            MountPoint('$', volume_graphs), 
            MountPoint('get_flight_data', get_flight_data)
            ]


def get_data_from_db(specific_date=None):

    piles = get_all_piles()
    flight_days = get_all_flights()

    volumes_for_flight_days = {
    '2024-10-31': [500, 3100, 2700, 1900, 1300, 2300, 1600, 950, 2550, 2100, 1650, 4050, 2850, 1050, 1750, 1350, 2450, 1150, 850, 2650, 3750, 1950, 2150],
    '2024-09-30': [150, 1150, 2750, 1920, 1320, 2350, 3050, 980, 580, 2200, 1680, 717, 880, 1080, 178, 1380, 2480, 1180, 880, 2680, 380, 1980, 2180],
    '2024-08-31': [130, 1820, 2780, 1940, 1340, 2380, 2680, 990, 590, 1250, 2690, 1150, 200, 190, 1790, 1390, 2490, 1190, 890, 2690, 3790, 1990, 2190],
    '2024-07-31': [550, 2200, 200, 1960, 1360, 2400, 3060, 1000, 600, 2300, 720, 420, 2950, 1120, 1820, 1420, 2520, 1220, 920, 2720, 320, 2020, 2220],
    '2024-06-30': [830, 1230, 2830, 1980, 1380, 230, 334, 1010, 610, 2350, 140, 4250, 2980, 1140, 1850, 1450, 2550, 120, 940, 2750, 380, 200, 2250],
    '2024-05-31': [600, 2250, 2850, 2000, 100, 2450, 330, 1020, 620, 1400, 1760, 4300, 300, 1060, 1880, 140, 2580, 1280, 960, 2780, 3880, 2080, 2280]
    }

    data = []
    for flight_day in flight_days:
        for pile, volume in zip(piles, volumes_for_flight_days[flight_day]):
            data.append([pile, volume, flight_day])

    df = pd.DataFrame(data, columns=['pile', 'volume', 'flightDay'])

    if not specific_date:
        specific_date = flight_days[0]  # get first in the list

    df = df[df['flightDay'] == specific_date]

    df['volume'] = df['volume'].astype(float)
    df['pile'] = df['pile'].astype(str)

    piles_array = df['pile'].values.tolist()  # x_values
    volumes_array = df['volume'].values.tolist()  # y_values

    return piles_array, volumes_array, flight_days


def get_all_flights() -> list[str]:
    all_flights = ['2024-10-31', '2024-09-30', '2024-08-31', '2024-07-31', '2024-06-30', '2024-05-31']
    return all_flights


def get_all_piles() -> list[str]:
    piles = ['SH', 'SC', 'TA', 'NL', 'NE', 'PN', 'HA', 'TS', 'XT', 'SH2', 'NL2', 'TA2', 'PN2', 'SC2', 'HS', 'JG', 'GJ', 'PS', 'LS', 'NS', 'KR', 'BD', 'KS']
    return piles
