# import pyodbc
# import pandas as pd

# connection_string = (
#     r"Driver={ODBC Driver 17 for SQL Server};"
#     r"Server=\\.\pipe\LOCALDB#C27096BB\tsql\query;"
#     r"Database=scraps;"
#     r"Trusted_Connection=yes;"
# )

# conn = pyodbc.connect(connection_string)
# query = "SELECT * FROM dbo.BLV"
# df = pd.read_sql(query, conn)
# conn.close()
# print(df)

# df['flightDay'] = pd.to_datetime(df['flightDay'])
# date_strings = df['flightDay'].dt.strftime('%Y-%m-%d').unique().tolist()
# print(date_strings)

import psycopg2
import pandas as pd

conn_params = {
    "dbname": "webodm_dev",
    "user": "postgres",
    "password": "",
    "host": "localhost",
    "port": "5433"
}

try:
    connection = psycopg2.connect(**conn_params)
    query = "SELECT * FROM BLV;"
    
    df = pd.read_sql(query, connection)

    print(df)
    connection.close()

except Exception as e:
    print(f"Error connecting to the database: {e}")

df['flightday'] = pd.to_datetime(df['flightday'])
date_strings = df['flightday'].dt.strftime('%Y-%m-%d').unique().tolist()
print(date_strings)
