const modern_colors = [
    "rgb(255, 99, 132)",    // Coral Pink
	"rgb(255, 87, 87)",     // Bright Red
	"rgb(255, 134, 159)",   // Soft Pink
	"rgb(219, 68, 88)",     // Deep Rose
    "rgb(255, 206, 86)",    // Bright Yellow
	"rgb(250, 176, 5)",     // Golden Yellow
	"rgb(255, 159, 64)",    // Orange
	"rgb(245, 124, 0)",     // Deep Orange
    "rgb(54, 162, 235)",    // Bright Blue'
	"rgb(36, 116, 204)",    // Royal Blue
	"rgb(116, 185, 255)",   // Sky Blue
    "rgb(75, 192, 192)",    // Turquoise
	"rgb(75, 192, 140)",    // Mint
	"rgb(47, 193, 140)",    // Emerald
	"rgb(111, 207, 151)",   // Spring Green
	"rgb(39, 174, 96)",     // Forest Green
	"rgb(153, 102, 255)",   // Bright Purple
	"rgb(142, 68, 173)",    // Deep Purple
	"rgb(155, 89, 182)",    // Lavender
    "rgb(201, 203, 207)",   // Cool Gray
	"rgb(103, 112, 120)",   // Slate Gray
	"rgb(87, 75, 144)",     // Deep Indigo
	"rgb(91, 60, 17)",      // Brown
	"rgb(66, 66, 66)",      // Charcoal
	"rgb(45, 52, 54)"       // Almost Black
];